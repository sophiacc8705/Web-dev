document.addEventListener("DOMContentLoaded", () => {
    setupProductPreferences();
    setupContactValidation();
});

const productCatalog = [
    { name: "Sourdough Loaf", category: "bread" },
    { name: "Whole Wheat Bread", category: "bread" },
    { name: "Focaccia", category: "bread" },
    { name: "Multigrain Loaf", category: "bread" },
    { name: "Croissants", category: "pastry" },
    { name: "Danish Pastries", category: "pastry" },
    { name: "Cinnamon Rolls", category: "pastry" },
    { name: "Fruit Tarts", category: "pastry" },
    { name: "Chocolate Layer Cake", category: "cake" },
    { name: "Vanilla Buttercream Cake", category: "cake" },
    { name: "Fruit Cake", category: "cake" },
    { name: "Custom Celebration Cake", category: "cake" }
];

const productCategories = [
    { id: "all", label: "all bakery products" },
    { id: "bread", label: "breads" },
    { id: "pastry", label: "pastries" },
    { id: "cake", label: "cakes" }
];

function setupProductPreferences() {
    const controls = document.querySelectorAll(".filter-button");
    const cards = document.querySelectorAll(".product-card[data-category]");
    if (!controls.length || !cards.length) return;

    const savedCategory = localStorage.getItem("northStarCategory") || "all";
    const savedFavorites = JSON.parse(localStorage.getItem("northStarFavorites") || "[]");

    cards.forEach((card, index) => {
        const product = productCatalog[index];
        const button = card.querySelector(".favorite-button");
        if (!button || !product) return;
        button.dataset.product = product.name;
        button.addEventListener("click", () => toggleFavorite(product.name, button));
        updateFavoriteButton(button, savedFavorites.includes(product.name));
    });

    controls.forEach(button => {
        button.addEventListener("click", () => {
            const category = button.dataset.category;
            localStorage.setItem("northStarCategory", category);
            applyCategoryFilter(category, controls, cards);
        });
    });

    applyCategoryFilter(savedCategory, controls, cards);
}

function applyCategoryFilter(category, controls, cards) {
    const selected = productCategories.find(item => item.id === category) || productCategories[0];
    controls.forEach(button => button.classList.toggle("active", button.dataset.category === selected.id));
    cards.forEach(card => {
        card.hidden = selected.id !== "all" && card.dataset.category !== selected.id;
    });
    const visibleCount = Array.from(cards).filter(card => !card.hidden).length;
    const status = document.getElementById("filter-status");
    if (status) status.textContent = `Showing ${visibleCount} ${selected.label}.`;
}

function toggleFavorite(productName, button) {
    let favorites = JSON.parse(localStorage.getItem("northStarFavorites") || "[]");
    if (favorites.includes(productName)) {
        favorites = favorites.filter(item => item !== productName);
        updateFavoriteButton(button, false);
    } else {
        favorites.push(productName);
        updateFavoriteButton(button, true);
    }
    localStorage.setItem("northStarFavorites", JSON.stringify(favorites));
}

function updateFavoriteButton(button, isFavorite) {
    button.setAttribute("aria-pressed", String(isFavorite));
    button.textContent = isFavorite ? "★ Favorited" : "☆ Add to Favorites";
    button.classList.toggle("is-favorite", isFavorite);
}

function setupContactValidation() {
    const form = document.getElementById("inquiry-form");
    if (!form) return;

    const savedName = localStorage.getItem("northStarName");
    const savedEmail = localStorage.getItem("northStarEmail");
    const savedRequestType = localStorage.getItem("northStarRequestType");
    if (savedName) document.getElementById("name").value = savedName;
    if (savedEmail) document.getElementById("email").value = savedEmail;
    if (savedRequestType) document.getElementById("request-type").value = savedRequestType;

    form.addEventListener("submit", event => {
        event.preventDefault();
        clearErrors();
        let valid = true;
        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const pickupDate = document.getElementById("pickup-date").value;
        const requestType = document.getElementById("request-type").value;
        const details = document.getElementById("item-details").value.trim();

        if (name.length < 2) { showError("name", "Please enter your name (at least 2 characters)."); valid = false; }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { showError("email", "Please enter a valid email address."); valid = false; }
        const today = new Date(); today.setHours(0, 0, 0, 0);
        const selectedDate = pickupDate ? new Date(`${pickupDate}T00:00:00`) : null;
        if (!selectedDate || selectedDate < today) { showError("pickup-date", "Pickup date must be today or a future date."); valid = false; }
        if (!requestType) { showError("request-type", "Please select a request type."); valid = false; }
        if (details.length < 10) { showError("item-details", "Please provide at least 10 characters of details."); valid = false; }
        if (!valid) return;

        localStorage.setItem("northStarName", name);
        localStorage.setItem("northStarEmail", email);
        localStorage.setItem("northStarRequestType", requestType);
        document.getElementById("form-success").textContent = "Thanks! Your request passed validation and is ready for bakery staff to review.";
    });
}

function showError(fieldId, message) {
    const field = document.getElementById(fieldId);
    const error = document.getElementById(`${fieldId}-error`);
    field.classList.add("input-error");
    if (error) error.textContent = message;
}

function clearErrors() {
    document.querySelectorAll(".field-error").forEach(error => error.textContent = "");
    document.querySelectorAll(".input-error").forEach(field => field.classList.remove("input-error"));
    const success = document.getElementById("form-success");
    if (success) success.textContent = "";
}
